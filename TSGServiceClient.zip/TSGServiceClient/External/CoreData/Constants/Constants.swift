//
//  Constants.swift
//  NewMonk
//
//  Created by Ikjot Kaur on 02/03/16.
//  Copyright © 2016 Naukri. All rights reserved.
//

import UIKit

let CRASH_ENTITY_NAME = "Crash"

//#if DEBUG
//let appRuningMode:AppRuningModeType = .DEBUG
//#else
//let appRuningMode:AppRuningModeType = .RELEASE
//#endif

